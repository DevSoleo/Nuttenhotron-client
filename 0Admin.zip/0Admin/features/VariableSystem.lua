_0Admin = {}

_0Admin["isStarted"] = false
_0Admin["key"] = ""

function saveVariable(name, value)
	_0Admin[name] = value
end